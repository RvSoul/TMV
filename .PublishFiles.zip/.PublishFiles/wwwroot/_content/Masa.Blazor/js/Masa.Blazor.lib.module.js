﻿export function beforeStart(options, extensions) {
}

export function afterStarted(blazor) {
}